<?php

	echo $_POST['graph_save'];

?>